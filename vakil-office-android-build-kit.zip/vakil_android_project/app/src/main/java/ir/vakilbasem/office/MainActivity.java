package ir.vakilbasem.office;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.util.Arrays;

public class MainActivity extends Activity {
    private WebView web; private SharedPreferences prefs; private ValueCallback<Uri[]> fileCallback; private static final int FILE_REQ=42;
    private final int BG=Color.rgb(14,20,25), GOLD=Color.rgb(208,174,102), TEXT=Color.rgb(238,242,244), MUTED=Color.rgb(166,181,190);
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(Color.rgb(20,45,37));getWindow().setNavigationBarColor(BG);prefs=getSharedPreferences("app_lock",MODE_PRIVATE);showLock();}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(17);return t;}
    private EditText pinField(){EditText e=new EditText(this);e.setInputType( android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setHint("رمز ۴ تا ۸ رقمی");e.setGravity(17);e.setLetterSpacing(.2f);return e;}
    private void showLock(){
        boolean setup=!prefs.contains("pin_hash"); LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(28,38,28,32);root.setGravity(17);root.setBackgroundColor(BG);
        TextView logo=text("⚖",48,GOLD);root.addView(logo);TextView title=text("دفتر وکالت باسم آلبوعلی",21,GOLD);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        root.addView(text(setup?"برای استفاده، رمز ورود اختصاصی تعیین کن":"رمز ورود برنامه را وارد کن",14,TEXT));
        EditText pin=pinField();LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,60);p.topMargin=25;root.addView(pin,p);
        EditText confirm=null;if(setup){confirm=pinField();confirm.setHint("تکرار رمز");LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,60);cp.topMargin=8;root.addView(confirm,cp);}
        Button go=new Button(this);go.setText(setup?"ثبت رمز و ورود":"ورود به برنامه");go.setTextColor(BG);go.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,55);bp.topMargin=18;root.addView(go,bp);
        TextView tip=text(setup?"رمز را فراموش نکن. در این نسخه بازیابی رمز از داخل برنامه ممکن نیست.":"اگر رمز را فراموش کرده‌ای، حذف داده‌های برنامه از تنظیمات اندروید قفل را بازنشانی می‌کند؛ داده‌های محلی نیز حذف می‌شوند.",11,MUTED);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=20;root.addView(tip,tp);
        setContentView(root);
        final EditText c=confirm;
        go.setOnClickListener(v->{String a=pin.getText().toString();if(a.length()<4||a.length()>8){toast("رمز باید ۴ تا ۸ رقم باشد");return;}if(setup){if(!a.equals(c.getText().toString())){toast("رمزها یکسان نیستند");return;}savePin(a);openApp();}else if(checkPin(a)){openApp();}else{pin.setText("");toast("رمز نادرست است");}});
    }
    private byte[] salt(){byte[] s=new byte[16];new SecureRandom().nextBytes(s);return s;}
    private String hash(String pin,byte[] salt)throws Exception{PBEKeySpec spec=new PBEKeySpec(pin.toCharArray(),salt,120000,256);byte[] h=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();spec.clearPassword();return android.util.Base64.encodeToString(h,android.util.Base64.NO_WRAP);}
    private void savePin(String pin){try{byte[] s=salt();prefs.edit().putString("pin_salt",android.util.Base64.encodeToString(s,android.util.Base64.NO_WRAP)).putString("pin_hash",hash(pin,s)).apply();}catch(Exception e){toast("خطا در تنظیم رمز");}}
    private boolean checkPin(String pin){try{byte[] s=android.util.Base64.decode(prefs.getString("pin_salt",""),android.util.Base64.NO_WRAP);return hash(pin,s).equals(prefs.getString("pin_hash",""));}catch(Exception e){return false;}}
    private void openApp(){
        web=new WebView(this);web.setBackgroundColor(BG);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(true);web.getSettings().setSupportZoom(false);web.getSettings().setBuiltInZoomControls(false);web.getSettings().setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;Intent i=params.createIntent();try{startActivityForResult(i,FILE_REQ);return true;}catch(Exception e){fileCallback=null;return false;}}});
        setContentView(web);web.loadUrl("file:///android_asset/app/index.html");
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==FILE_REQ&&fileCallback!=null){Uri[] r=result==RESULT_OK&&data!=null?(data.getData()!=null?new Uri[]{data.getData()}:data.getClipData()!=null?new Uri[]{data.getClipData().getItemAt(0).getUri()}:null):null;fileCallback.onReceiveValue(r);fileCallback=null;}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
